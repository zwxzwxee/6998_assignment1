import json
import boto3
import io
from datetime import datetime
import urllib.parse
from requests_aws4auth import AWS4Auth
import requests

def lambda_handler(event, context):
    region = 'us-east-1'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    host = 'https://search-chatbot-uxle3neo5ximnmp2q3szln3e6a.us-east-1.es.amazonaws.com'
    index = 'restaurants'
    type = '_doc'
    url = host + '/' + index + '/' + type
    headers = {"Content-Type": "application/json"}

    aws_session = boto3.Session()
    client = aws_session.client('s3', region_name="us-east-1")
    # bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    # key = "chinese.json"
    json_obj = client.get_object(Bucket="chatbot-6998", Key=key)
    file_content = json_obj['Body'].read().decode('utf-8')
    json_content = json.loads(file_content)
    businesses = json_content['businesses']

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('yelp-restaurants')

    for i in range(len(businesses)):
        b = businesses[i]
        item = {
            "insertedAtTimestamp": datetime.now().strftime("%m/%d/%Y, %H:%M:%S"),
            'businessId': b['id'],
            'name': b['name'],
            'address': ','.join(b['location']['display_address']),
            'zipCode': b['location']['zip_code'],
            'coordinates': str(b['coordinates']),
            'rating': str(b['rating']),
            'reviewCount': str(b['review_count'])
        }
        response = table.put_item(Item=item)
        document = {"restaurantid": b['id'], "cuisine": key[:-5]}
        r = requests.post(url, auth=awsauth, json=document, headers=headers)
    return {
        'statusCode': 200,
        'message': r.text
    }

