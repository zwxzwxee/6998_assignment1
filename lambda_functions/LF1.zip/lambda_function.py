import json
import random
import decimal 
import boto3


def get_slots(intent_request):
    return intent_request['sessionState']['intent']['slots']
    
def get_slot(intent_request, slotName):
    slots = get_slots(intent_request)
    if slots is not None and slotName in slots and slots[slotName] is not None:
        return slots[slotName]['value']['interpretedValue']
    else:
        return None    

def get_session_attributes(intent_request):
    sessionState = intent_request['sessionState']
    if 'sessionAttributes' in sessionState:
        return sessionState['sessionAttributes']

    return {}

def elicit_intent(intent_request, session_attributes, message):
    return {
        'sessionState': {
            'dialogAction': {
                'type': 'ElicitIntent'
            },
            'sessionAttributes': session_attributes
        },
        'messages': [ message ] if message != None else None,
        'requestAttributes': intent_request['requestAttributes'] if 'requestAttributes' in intent_request else None
    }


def close(intent_request, session_attributes, fulfillment_state, message):
    intent_request['sessionState']['intent']['state'] = fulfillment_state
    return {
        'sessionState': {
            'sessionAttributes': session_attributes,
            'dialogAction': {
                'type': 'Close'
            },
            'intent': intent_request['sessionState']['intent']
        },
        'messages': [message],
        'sessionId': intent_request['sessionId'],
        'requestAttributes': intent_request['requestAttributes'] if 'requestAttributes' in intent_request else None
    }
    
def dispatch(intent_request):
    intent_name = intent_request['sessionState']['intent']['name']
    response = None
    session_attributes = get_session_attributes(intent_request)
    text = "You’re all set. Expect my suggestions shortly! Have a good day."
    message =  {
            'contentType': 'PlainText',
            'content': text
        }
    fulfillment_state = "Fulfilled"    
    return close(intent_request, session_attributes, fulfillment_state, message)

    raise Exception('Intent with name ' + intent_name + ' not supported')

def createMessage(intent_request):
    slots = get_slots(intent_request)
    location = get_slot(intent_request,"Location")
    cuisine = get_slot(intent_request,"cuisine")
    people = get_slot(intent_request,"people")
    date = get_slot(intent_request,"date")
    time = get_slot(intent_request,"time")
    phone = get_slot(intent_request,"phonenumber")
    
    data = {
        'location': {
            'DataType': 'String',
            'StringValue': location
        },
        'cuisine': {
            'DataType': 'String',
            'StringValue': cuisine
        },
        'people': {
            'DataType': 'String',
            'StringValue': str(people)
        },
        'date': {
            'DataType': 'String',
            'StringValue': str(date)
        },
        'time': {
            'DataType': 'String',
            'StringValue': str(time)
        },
        'phone': {
            'DataType': 'String',
            'StringValue': str(phone)
        },
        
    }
    
    # data = {'location':location,'cuisine':cuisine,'people':people,'date':date,'time':time,'phone':phone}
    
    return data
    
def lambda_handler(event, context):
    client = boto3.client("sqs")
    data = createMessage(event)
    response = dispatch(event)
    # MessageBody=json.dumps(data)
    client.send_message(
        QueueUrl="https://sqs.us-east-1.amazonaws.com/902672276522/msgQueue", 
        MessageAttributes=data, 
        MessageBody=("this is message body")
    )
    return response