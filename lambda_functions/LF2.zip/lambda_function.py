import json
import boto3
import io
from datetime import datetime
import urllib.parse
from requests_aws4auth import AWS4Auth
import requests


def lambda_handler(event, context):
    sqs = boto3.client('sqs')

    queue_url = 'https://sqs.us-east-1.amazonaws.com/902672276522/msgQueue'

    # Receive message from SQS queue
    response = sqs.receive_message(
        QueueUrl=queue_url,
        AttributeNames=[
            'SentTimestamp'
        ],
        MaxNumberOfMessages=1,
        MessageAttributeNames=[
            'All'
        ],
        VisibilityTimeout=0,
        WaitTimeSeconds=0
    )

    message = response['Messages'][0]
    
    attributes = message['MessageAttributes']
    cuisine = attributes['cuisine']['StringValue'].capitalize()
    people = attributes['people']['StringValue']
    date =  attributes['date']['StringValue']
    time = attributes['time']['StringValue']
    phone = "+1"+attributes['phone']['StringValue']
    
    receipt_handle = message['ReceiptHandle']

    # Delete received message from queue
    sqs.delete_message(
        QueueUrl=queue_url,
        ReceiptHandle=receipt_handle
    )
    
    # open search
    region = 'us-east-1'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    host = 'https://search-chatbot-uxle3neo5ximnmp2q3szln3e6a.us-east-1.es.amazonaws.com'
    index = 'restaurants'
    url = host + '/' + index + '/_search'
    headers = { "Content-Type": "application/json" }
    size = 3
    query = {
        "size": size,
        "query": {
            "multi_match": {
                "query":cuisine,
                "fields": ["cuisine"]
            }
        }
    }
    
    r = requests.get(url, auth=awsauth, headers=headers, data=json.dumps(query))
    response = r.json()
    id_list = []
    for i in range(size):
        id_list.append(response['hits']['hits'][i]['_source']['restaurantid'])

    # dynamodb
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table('yelp-restaurants')
    
    text = []    
    greeting = "Hello! Here are my {} restaurant suggestions for {} people, for {} at {}: ".format(cuisine,people,date,time)
    text.append(greeting)
    for i in range(size):
        res_id = id_list[i]
        response = table.get_item(Key={'businessId': res_id})
        name = response['Item']['name']
        address = response['Item']['address']
        res_info = "{}. {}, located at {}".format(i+1,name,address)
        text.append(res_info)
        if i==size-1:
            text.append(". ")
        else:
            text.append(', ')
    ending = "Enjoy your meal!"
    text.append(ending)
    
    text = "".join(text)
    
    # sns = boto3.resource('sns')
    # topic_name = "diningSuggestions"
    # topic = sns.create_topic(Name=topic_name)
    # response = sns.meta.client.publish(PhoneNumber=phone,Message=text)
    # message_id = response['MessageId']
    
    
    # we use phone to store email_address for convenience
    recipient = phone[2:]
    source_email = 'zwxzwxee@gmail.com'
    client = boto3.client('ses')
    response = client.send_email(
    Destination={
        'ToAddresses': [
            recipient
        ],
    },
    Message={
        'Body': {
            'Html': {
                'Charset': 'UTF-8',
                'Data': '<p>'+text+'</p>',
            },
            'Text': {
                'Charset': 'UTF-8',
                'Data': text,
            },
        },
        'Subject': {
            'Charset': 'UTF-8',
            'Data': 'Dining Suggestion',
        },
    },
    Source=source_email,
    )
    message_id = response['MessageId']

    return {
        'statusCode': 200,
        'cuisine':cuisine,
        'phone':phone,
        'people':people,
        'date':date,
        'time':time,
        'message_id':message_id,
        'message':text
    }



